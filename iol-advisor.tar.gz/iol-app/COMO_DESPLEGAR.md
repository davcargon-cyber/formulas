# Cómo poner IOL Advisor en marcha

Todo el proceso son 10 minutos, una sola vez. Después solo usas la web.

---

## Paso 1 — Crear cuenta en GitHub (2 min)

GitHub es donde se guardan los archivos del programa. Es gratis.

1. Ve a **https://github.com/signup**
2. Crea una cuenta con tu email
3. Confirma el email

---

## Paso 2 — Subir los archivos a GitHub (3 min)

1. Inicia sesión en GitHub
2. Ve a **https://github.com/new**
3. En "Repository name" escribe: `iol-advisor`
4. Déjalo en **Public**
5. Pulsa **"Create repository"**
6. En la página que aparece, pulsa **"uploading an existing file"**
7. Arrastra TODOS los archivos de la carpeta que has descargado:
   - `app.py`
   - `Dockerfile`
   - `requirements.txt`
   - `render.yaml`
   - la carpeta `templates/` (con `index.html` dentro)
8. Pulsa **"Commit changes"**

---

## Paso 3 — Conseguir la API key de Anthropic (2 min)

Esta es la "contraseña" que permite que el programa use la inteligencia artificial de Claude.

1. Ve a **https://console.anthropic.com/**
2. Crea una cuenta (o inicia sesión)
3. En el menú lateral, pulsa **"API Keys"**
4. Pulsa **"Create Key"**
5. Ponle el nombre "IOL Advisor"
6. **Copia la key** (empieza por `sk-ant-...`). Guárdala en un sitio seguro, no la podrás volver a ver.

> **Coste:** Cada consulta (subir un PDF y obtener resultados) cuesta ~0.05€.
> Para empezar tienes $5 de crédito gratuito.

---

## Paso 4 — Desplegar en Render (3 min)

Render es el servicio que ejecuta el programa en internet. Tiene capa gratuita.

1. Ve a **https://render.com/**
2. Pulsa **"Get Started for Free"**
3. **Regístrate con tu cuenta de GitHub** (botón "GitHub")
4. Una vez dentro, pulsa **"New" → "Web Service"**
5. Busca tu repositorio `iol-advisor` y pulsa **"Connect"**
6. Render detectará el Dockerfile automáticamente. Verifica:
   - Name: `iol-advisor`
   - Region: `Frankfurt` (la más cercana a España)
   - Instance Type: **Free**
7. Pulsa **"Advanced"** y luego **"Add Environment Variable"**:
   - Key: `ANTHROPIC_API_KEY`
   - Value: pega aquí tu API key (la de `sk-ant-...`)
8. Pulsa **"Create Web Service"**

Render tardará 5-10 minutos en construir todo. Verás los logs en pantalla.
Cuando termine, verás un enlace tipo:

**`https://iol-advisor-xxxx.onrender.com`**

Esa es TU web. Ábrela y ya puedes usar IOL Advisor.

---

## Uso diario

1. Abre tu enlace (`https://iol-advisor-xxxx.onrender.com`)
2. Sube el PDF de la biometría
3. Verifica los datos y pulsa "Calcular 7 fórmulas"
4. Espera ~1 minuto
5. Recibes resultados de las 7 fórmulas + recomendación

**Nota:** En el plan gratuito de Render, si no usas la web durante 15 minutos,
el servidor se "duerme". La primera vez que entres después tardará ~30 segundos
en despertar. Después funciona normal.

---

## Problemas frecuentes

**"La web no carga"**
→ El servidor puede estar dormido. Espera 30 segundos y recarga.

**"Error en la extracción del PDF"**
→ El formato del PDF puede no ser legible. Prueba con una imagen (captura de pantalla del biómetro).

**"No se obtuvieron resultados de la ESCRS"**
→ La web de la ESCRS puede estar caída o haber cambiado su estructura. Inténtalo más tarde.

**"Error de API key"**
→ Ve a Render → tu servicio → Environment → verifica que la key está bien pegada.

**¿Cuánto cuesta mantener esto?**
→ Render gratis + ~0.05€ por consulta en Anthropic. Para uso clínico típico (5-10 pacientes/día) serían ~15€/mes.

---

## Actualizar

Si necesitas actualizar el código (por ejemplo, porque la ESCRS cambió su web):

1. Ve a tu repositorio en GitHub
2. Edita el archivo que necesites
3. Render detecta el cambio y se actualiza solo
